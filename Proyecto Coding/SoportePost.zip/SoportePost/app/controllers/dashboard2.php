<?php
class Dashboard2 extends Controller {
        public $view;

    public function __construct() {
        parent::__construct();
    }

    public function index(): void {
        session_start();
        Model::exists('dashboard2');

        // Incorporates the FrontEnd Controller
        $this->view->js = array('Tecnico/dashboard2/js/frontEnd.js');
        $this->view->render('Tecnico/dashboard2/index', 1);
    }
}
?>
