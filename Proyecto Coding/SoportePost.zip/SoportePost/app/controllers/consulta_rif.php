<?php
class consulta_rif extends Controller {
        public $view;

    public function __construct() {
        parent::__construct();
    }

    public function index(): void {
        session_start();
        Model::exists('consulta_rif');

        // Incorporates the FrontEnd Controller
        $this->view->js = array('Tecnico/consulta_rif/js/frontEnd.js');
        $this->view->render('Tecnico/consulta_rif/index', 1);
    }
}
?>
