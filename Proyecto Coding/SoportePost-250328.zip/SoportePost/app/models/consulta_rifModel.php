<?php
require_once __DIR__ . "/../../libs/Model.php";
require_once __DIR__ . "/../../libs/session.php";

class consulta_rifModel extends Model
{

    public $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = DatabaseCon::getInstance(bd_hostname, mvc_port, bd_usuario, bd_clave, database);
    }

    public function SearchRif($rif)
    {
        try {
            $sql = "SELECT *
            FROM dblink(
                'host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
                $$
                    	SELECT cli.id_consecutivo AS id_cliente, cli.razonsocial, cli.coddocumento AS rif, cli.tipopos AS tipocomunicacion, tbl.tipopos AS name_tipopos, 
                        mod.desc_modelo as name_modelopos, cli.codmodelopos as modelopos, pos.serialpos, 
                    pos.nroafiliacion AS afiliacion, DATE(pos.fechainstalacion) as fechainstalacion, tblcod.ibp as banco,
                    cli.direccion_instalacion, cli.estado AS id_estado, tbles.estado, cli.municipio AS id_municipio, tblmun.municipio
                    FROM clie_tblclientepotencial cli
                    INNER JOIN tbltipopos tbl ON tbl.codtipo::integer = cli.tipopos::integer
					INNER JOIN tblmodelopos mod ON mod.codmodelo = cli.codmodelopos
                    INNER JOIN tblbanco tblcod ON tblcod.codigobanco::integer = cli.codigobanco::integer
                    INNER JOIN tblinventariopos pos ON pos.id_cliente::integer = cli.id_consecutivo::integer
                    LEFT JOIN tblestados tbles ON tbles.id_estado::integer = cli.estado::integer
                    LEFT JOIN tblmunicipios tblmun ON tblmun.id_municipio::integer = cli.municipio::integer
                    WHERE cli.coddocumento = '".$rif."'
                    GROUP BY cli.id_consecutivo, cli.razonsocial, cli.coddocumento,  cli.tipopos, tbl.tipopos, mod.desc_modelo, cli.codmodelopos, pos.serialpos, afiliacion, pos.fechainstalacion,
                    tblcod.ibp, cli.direccion_instalacion, cli.estado, tbles.estado, cli.municipio, tblmun.municipio
					
                $$
            ) AS remote_table (
                id_cliente integer,
                razonsocial text,
                rif text,
				tipocomunicacion integer,
                name_tipopos text,
				name_modelopos text,
                modelopos integer,
                serial_pos text,
                afiliacion text,
                fechainstalacion date,
                banco text,
                direccion_instalacion text,
                id_estado integer,
                estado text,
                id_municipio integer,
                municipio text
            );";
            //var_dump($sql);
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function SearchSerial($serial)
    {
        try {
            $sql = "SELECT *
     FROM dblink(
      'host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
       $$
        SELECT
            inv.serialpos AS Serial_POS,
            inv.id_cliente::integer AS ID_cliente,
            inv.numterminal AS Numero_Terminal,
            tbl.tipopos AS name_tipopos,
            inv.numsim AS Numero_SIM,
            inv.usuariocarga AS Usuario_Carga,
            inte.desc_estatus AS Estatus_POS,
            inv.serialmifi AS Serial_Mifi,
            inv.usuariocarga AS Usuario_Carga2,
            DATE(inv.fechacarga) AS Fecha_Carga, -- Extrae solo la fecha
            inv.usuarioparametro AS Usuario_Parametro,
            DATE(inv.fechaparametro) AS Fecha_Parametro, -- Extrae solo la fecha
            clie.codmodelopos::integer as modelo
        FROM
            tblinventariopos inv
        INNER JOIN
            tblestatusinteliservices inte ON inte.idestatus = inv.idestatusinteliservices
        INNER JOIN
            clie_tblclientepotencial clie ON clie.id_consecutivo::integer = inv.id_cliente::integer
		INNER JOIN 
            tblmodelopos mod ON mod.codmodelo = clie.codmodelopos
        INNER JOIN 
		 	tbltipopos tbl ON tbl.codtipo::integer = clie.tipopos::integer

        WHERE
            inv.serialpos = '".$serial."'
                $$
            ) AS remote_table (
                Serial_POS text,
                ID_cliente integer,
                Numero_Terminal text,
                name_tipopos text,
                Numero_SIM text,
                Usuario_Carga text,
                Estatus_POS text,
                Serial_Mifi text,
                Usuario_Carga2 text,
                Fecha_Carga date,
                Usuario_Parametro text,
                Fecha_Parametro date,
                modelo integer
                    );";
            //var_dump($sql);     
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }
    
    public function GetInstallDate(){
        try{
            $sql = "SELECT count(*) as users FROM users;";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        } 
    }

    public function VerifingClient($rif){
        try {
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
                    'SELECT inv.id_consecutivo AS id_cliente, CAST(inv.coddocumento AS TEXT) AS rif FROM clie_tblclientepotencial inv 
                    WHERE inv.coddocumento = ''".$rif."'''
                ) AS remote_table (
                    id_cliente INTEGER,
                    rif TEXT
                )";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function GetPosSerialsByRif($rif){
        try {
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
           'SELECT tbl.serialpos as serial FROM clie_tblclientepotencial inv 
					 INNER JOIN tblinventariopos tbl ON tbl.id_cliente::integer = inv.id_consecutivo 
           wHERE inv.coddocumento = ''".$rif."''') AS remote_table (serial TEXT);";
            $result = Model::getResult($sql, $this->db);
            //var_dump( $result);
        return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function SearchtypePos($serial){
        try {
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
        $$
         SELECT cli.codmodelopos::integer as modelo FROM clie_tblclientepotencial cli
         INNER JOIN tblmodelopos mod ON mod.codmodelo = cli.codmodelopos
         INNER JOIN tblinventariopos inv ON inv.id_cliente::integer = cli.id_consecutivo::integer WHERE inv.serialpos = '".$serial."'
        $$
        ) AS remote_table (codmodelopos integer);";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function SaveDataFalla($serial, $falla, $nivelFalla){
        session_start();
        try {
            $sql = "INSERT INTO tickets_n1 (date_create, id_user, serial_pos, id_status_ticket, id_process_ticket, id_accion_ticket, id_failure, id_level_failure) 
                     values ( NOW(), ".$_SESSION['id_user'].", '".$serial."', 1, 1, 2, ".$falla.", ".$nivelFalla.");";
                    //var_dump($sql);
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function SaveDataFalla2($serial, $descripcion, $nivelFalla, $coordinador, $rutaBaseDatos){
        session_start();
        try {
            $sql = "INSERT INTO tickets_n2 (id_status_ticket, id_user, id_process_ticket, id_accion_ticket, id_status_payment, date_create_ticket, 
                     serial_pos, id_user_coord, id_failure, id_level_failure, downl_send_to_rosal) 
                    VALUES (1, ".$_SESSION['id_user'].", 1, 1, 1, NOW(), '".$serial."', ".$coordinador.", ".$descripcion.", ".$nivelFalla.", encode(pg_read_binary_file('".$rutaBaseDatos."'), 'base64')::bytea)";
                    //var_dump($sql);
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
                // Handle exception
        }
    }

    public function GetExpiredSessions($usuario_id, $ahora) {
        try {
            $sql = "SELECT id_session FROM sessions_users WHERE id_user = ".$usuario_id." AND active = 1 AND expiry_time <= '".$ahora."';";
            //var_dump($sql);
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function UpdateSessionExpired($id_session) {
        try {
            $sql = "UPDATE sessions_users SET active = 0, end_date = NOW() WHERE id_session = '".$id_session."';";
            //var_dump($sql);
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function UltimateDateTicket($serial){
        try{
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=soporte_postventa user=postgres password=Airan1234',
                    'SELECT inv.fecha_cierre AS ult_ticket FROM tk inv WHERE inv.serialpos = ''".$serial."''') 
                    AS remote_table (ult_ticket date);";
                    $result = Model::getResult($sql, $this->db);
                    return $result;
        } catch (Throwable $e) {
                    // Manejar excepciones
        }
    }

    public function InstallDatePOS($serial){
        try{
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
                    'SELECT inv.fechainstalacion AS inst_ticket FROM tblinventariopos inv WHERE inv.serialpos = ''".$serial."''') 
                    AS remote_table (inst_ticket date);";
                    //var_dump($sql);
                    $result = Model::getResult($sql, $this->db);
                    return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function GetFailure1(){
        try{
            $sql = "SELECT id_failure, name_failure, id_failure_level FROM failures  WHERE id_failure_level = 1";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function GetFailure2(){
        try{
            $sql = "SELECT id_failure, name_failure, id_failure_level FROM failures  WHERE id_failure_level = 2";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function GetCoordinator(){
        try{
            $sql = "SELECT id_user, CONCAT(name, ' ', surname) as full_name FROM users WHERE id_rolusr = 4";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }
}
?>