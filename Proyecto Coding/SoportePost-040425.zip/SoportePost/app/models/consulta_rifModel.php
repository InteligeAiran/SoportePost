<?php
require_once __DIR__ . "/../../libs/Model.php";
require_once __DIR__ . "/../../libs/session.php";

class consulta_rifModel extends Model
{

    public $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = DatabaseCon::getInstance(bd_hostname, mvc_port, bd_usuario, bd_clave, database);
    }

    public function SearchRif($rif)
    {
        try {
            $sql = "SELECT *
            FROM dblink(
                'host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
                $$
                    	SELECT cli.id_consecutivo AS id_cliente, cli.razonsocial, cli.coddocumento AS rif, cli.tipopos AS tipocomunicacion, tbl.tipopos AS nombre_tipo_POS, 
                        mod.desc_modelo as name_modelopos, cli.codmodelopos as modelopos, pos.serialpos, 
                    pos.nroafiliacion AS afiliacion, DATE(pos.fechainstalacion) as fechainstalacion, tblcod.ibp as banco,
                    cli.direccion_instalacion, cli.estado AS id_estado, tbles.estado, cli.municipio AS id_municipio, tblmun.municipio
                    FROM clie_tblclientepotencial cli
                    INNER JOIN tbltipopos tbl ON tbl.codtipo::integer = cli.tipopos::integer
					INNER JOIN tblmodelopos mod ON mod.codmodelo = cli.codmodelopos
                    INNER JOIN tblbanco tblcod ON tblcod.codigobanco::integer = cli.codigobanco::integer
                    INNER JOIN tblinventariopos pos ON pos.id_cliente::integer = cli.id_consecutivo::integer
                    LEFT JOIN tblestados tbles ON tbles.id_estado::integer = cli.estado::integer
                    LEFT JOIN tblmunicipios tblmun ON tblmun.id_municipio::integer = cli.municipio::integer
                    WHERE cli.coddocumento = '".$rif."'
                    GROUP BY cli.id_consecutivo, cli.razonsocial, cli.coddocumento,  cli.tipopos, tbl.tipopos, mod.desc_modelo, cli.codmodelopos, pos.serialpos, afiliacion, pos.fechainstalacion,
                    tblcod.ibp, cli.direccion_instalacion, cli.estado, tbles.estado, cli.municipio, tblmun.municipio
					
                $$
            ) AS remote_table (
                id_cliente integer,
                razonsocial text,
                rif text,
				tipocomunicacion integer,
                nombre_tipo_POS text,
				name_modelopos text,
                modelopos integer,
                serial_pos text,
                afiliacion text,
                fechainstalacion date,
                banco text,
                direccion_instalacion text,
                id_estado integer,
                estado text,
                id_municipio integer,
                municipio text
            );";
            //var_dump($sql);
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function SearchSerial($serial)
    {
        try {
            $sql = "SELECT *
     FROM dblink(
      'host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
       $$
        SELECT
            inv.serialpos AS Serial_POS,
            inv.id_cliente::integer AS ID_cliente,
            inv.numterminal AS Numero_Terminal,
            tbl.tipopos AS nombre_tipo_POS,
            inv.numsim AS Numero_SIM,
            inv.usuariocarga AS Usuario_Carga,
            inte.desc_estatus AS Estatus_POS,
            inv.serialmifi AS Serial_Mifi,
            inv.usuariocarga AS Usuario_Carga2,
            DATE(inv.fechacarga) AS Fecha_Carga, -- Extrae solo la fecha
            inv.usuarioparametro AS Usuario_Parametro,
            DATE(inv.fechaparametro) AS Fecha_Parametro, -- Extrae solo la fecha
            clie.codmodelopos::integer as modelo
        FROM
            tblinventariopos inv
        INNER JOIN
            tblestatusinteliservices inte ON inte.idestatus = inv.idestatusinteliservices
        INNER JOIN
            clie_tblclientepotencial clie ON clie.id_consecutivo::integer = inv.id_cliente::integer
		INNER JOIN 
            tblmodelopos mod ON mod.codmodelo = clie.codmodelopos
        INNER JOIN 
		 	tbltipopos tbl ON tbl.codtipo::integer = clie.tipopos::integer

        WHERE
            inv.serialpos = '".$serial."'
                $$
            ) AS remote_table (
                Serial_POS text,
                ID_cliente integer,
                Numero_Terminal text,
                nombre_tipo_POS text,
                Numero_SIM text,
                Usuario_Carga text,
                Estatus_POS text,
                Serial_Mifi text,
                Usuario_Carga2 text,
                Fecha_Carga date,
                Usuario_Parametro text,
                Fecha_Parametro date,
                modelo integer
                    );";
            //var_dump($sql);     
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }
    
    public function GetInstallDate(){
        try{
            $sql = "SELECT count(*) as users FROM users;";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        } 
    }

    public function VerifingClient($rif){
        try {
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
                    'SELECT inv.id_consecutivo AS id_cliente, CAST(inv.coddocumento AS TEXT) AS rif FROM clie_tblclientepotencial inv 
                    WHERE inv.coddocumento = ''".$rif."'''
                ) AS remote_table (
                    id_cliente INTEGER,
                    rif TEXT
                )";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function GetPosSerialsByRif($rif){
        try {
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
           'SELECT tbl.serialpos as serial FROM clie_tblclientepotencial inv 
					 INNER JOIN tblinventariopos tbl ON tbl.id_cliente::integer = inv.id_consecutivo 
           wHERE inv.coddocumento = ''".$rif."''') AS remote_table (serial TEXT);";
            $result = Model::getResult($sql, $this->db);
            //var_dump( $result);
        return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function SearchtypePos($serial){
        try {
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
        $$
         SELECT cli.codmodelopos::integer as modelo FROM clie_tblclientepotencial cli
         INNER JOIN tblmodelopos mod ON mod.codmodelo = cli.codmodelopos
         INNER JOIN tblinventariopos inv ON inv.id_cliente::integer = cli.id_consecutivo::integer WHERE inv.serialpos = '".$serial."'
        $$
        ) AS remote_table (codmodelopos integer);";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function VerifingBranches($rif){
        try {
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
            $$
                SELECT clie.estado, est.estado
                FROM clie_tblclientepotencial clie
                INNER JOIN tblestados est ON est.id_estado::INTEGER = clie.estado::INTEGER
                WHERE clie.coddocumento = '".$rif."'
            $$
            ) AS remote_table (id_estado TEXT, nombre_estado TEXT);";
            //var_dump($sql);
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function GetRegionFromState($id_state){
        try{
            $sql = "SELECT est.id_state, est.name_state, reg.id_region, reg.name_region FROM states est 
                INNER JOIN regions reg ON reg.id_region = est.id_region WHERE est.id_state = ".$id_state.";";
          $result = Model::getResult($sql, $this->db);
          return $result;
        } catch (Throwable $e) {
          // Handle exception
        }
    }

    public function SaveDataFalla($serial, $falla, $nivelFalla){
        session_start();
        try {
            $sql = "INSERT INTO tickets (date_create_ticket, id_user, serial_pos, id_status_ticket, id_process_ticket, id_accion_ticket, id_failure, id_level_failure) 
                     values ( NOW(), ".$_SESSION['id_user'].", '".$serial."', 1, 1, 2, ".$falla.", ".$nivelFalla.");";
                    //var_dump($sql);
                    $result = $this->db->pgquery($sql);
                    return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function InsertTickets_Failures($falla){
        try {
            $sql = "INSERT INTO tickets_failures (id_failure) 
                     values (".$falla.");";
                    //var_dump($sql);
                    $result = $this->db->pgquery($sql);
                    return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function SaveDataFalla2($serial, $descripcion, $nivelFalla, $coordinador, $rutaBaseDatos, $id_status_payment,  $rutaExo, $rutaAnticipo){
        session_start();
        try {
            $sql = "INSERT INTO tickets (id_status_ticket, id_user, id_process_ticket, id_accion_ticket, id_status_payment, date_create_ticket, 
                     serial_pos, id_user_coord, id_failure, id_level_failure, downl_send_to_rosal, downl_exoneration, downl_payment) 
                    VALUES (1, ".$_SESSION['id_user'].", 1, 1, ".$id_status_payment.", NOW(), '".$serial."', ".$coordinador.", ".$descripcion.", ".$nivelFalla."";

                    // Archivo de exoneración
                    if (!empty($rutaBaseDatos)) {
                        $sql .= ", encode(pg_read_binary_file('".$rutaBaseDatos."'), 'base64')::bytea, ";
                    } else {
                        $sql .= ", NULL, ";
                    }

                    // Archivo de exoneración
                    if (!empty($rutaExo)) {
                        $sql .= "encode(pg_read_binary_file('".$rutaExo."'), 'base64')::bytea, ";
                    } else {
                        $sql .= "NULL, ";
                    }

                    // Archivo de anticipo
                    if (!empty($rutaAnticipo)) {
                        $sql .= "encode(pg_read_binary_file('".$rutaAnticipo."'), 'base64')::bytea)";
                    } else {
                        $sql .= "NULL)";
                    }

                    //var_dump($sql);
                    $result = $this->db->pgquery($sql);
                    return $result;
        } catch (Throwable $e) {
                // Handle exception
        }
    }

    public function GetExpiredSessions($usuario_id, $ahora) {
        try {
            $sql = "SELECT id_session FROM sessions_users WHERE id_user = ".$usuario_id." AND active = 1 AND expiry_time <= '".$ahora."';";
            //var_dump($sql);
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function UpdateSessionExpired($id_session) {
        try {
            $sql = "UPDATE sessions_users SET active = 0, end_date = NOW() WHERE id_session = '".$id_session."';";
            //var_dump($sql);
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function UltimateDateTicket($serial){
        try{
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=soporte_postventa user=postgres password=Airan1234',
                    'SELECT inv.fecha_cierre AS ult_ticket FROM tk inv WHERE inv.serialpos = ''".$serial."''') 
                    AS remote_table (ult_ticket date);";
                    $result = Model::getResult($sql, $this->db);
                    return $result;
        } catch (Throwable $e) {
                    // Manejar excepciones
        }
    }

    public function InstallDatePOS($serial){
        try{
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
                    'SELECT inv.fechainstalacion AS inst_ticket FROM tblinventariopos inv WHERE inv.serialpos = ''".$serial."''') 
                    AS remote_table (inst_ticket date);";
                    //var_dump($sql);
                    $result = Model::getResult($sql, $this->db);
                    return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function GetFailure1(){
        try{
            $sql = "SELECT id_failure, name_failure, id_failure_level FROM failures  WHERE id_failure_level = 1";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function GetFailure2(){
        try{
            $sql = "SELECT id_failure, name_failure, id_failure_level FROM failures  WHERE id_failure_level = 2";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function GetCoordinator(){
        try{
            $sql = "SELECT id_user, CONCAT(name, ' ', surname) as full_name FROM users WHERE id_rolusr = 4";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }
}
?>