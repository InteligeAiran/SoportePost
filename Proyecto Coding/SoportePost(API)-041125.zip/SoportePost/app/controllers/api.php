<?php
require_once 'app/models/loginModel.php';
require_once 'app/models/userModel.php';
require_once __DIR__ . "/../../libs/Controller.php";
require_once 'libs/database_cn.php';
require_once 'libs/View.php';
require_once 'libs/database.php';
require_once 'app/repositories/LoginRepository.php';
require_once 'app/repositories/UserRepository.php';
require_once __DIR__ . '/../../config/paths.php';

require_once __DIR__ . '/../views/login/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../views/login/PHPMailer/Exception.php'; 
require_once __DIR__ . '/../views/login/PHPMailer/SMTP.php'; 


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

Use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
use App\Repositories\UserRepository;
use App\Repositories\LoginRepository;

class Api extends Controller {
    private $db;
    private $userRepository;
    private $loginRepository; // Asegúrate de instanciarlo si lo usas en handleLogin

    function __construct() {
        parent::__construct();
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
        header('Access-Control-Allow-Headers: Content-Type');

        $this->db = DatabaseCon::getInstance(bd_hostname, mvc_port, bd_usuario, bd_clave, database);
        // $this->userRepository = new UserRepository(); // Instancia el UserRepository aquí si lo vas a usar
        $this->loginRepository = new LoginRepository();
    }

    public function processApi($urlSegments) {
        $method = $_SERVER['REQUEST_METHOD'];

        // Enrutamiento basado en los segmentos de la URL
        if (isset($urlSegments[0])) {
            switch ($urlSegments[0]) {

                case 'users':
                    // Pasar los segmentos de la URL a la función handleUsers
                    // y manejar la lógica de obtención de usuarios
                    $this->handleUsers($method, $urlSegments); 
                break;

                case 'login':
                    // El método POST para login puede seguir como está
                    $this->handleLogin(); 
                break;

                /*case 'logout':
                    // Manejo de la sesión de cierre de sesión
                    session_start();
                    session_destroy();
                    $this->response(['success' => true, 'message' => 'Sesión cerrada correctamente'], 200);
                break;*/

                case 'checkPass':
                    // Manejo de la verificación de contraseña
                    $this->handlePassword();
                break;

                case 'checkUser':
                    // Manejo de la verificación de nombre de usuario
                    $this->handleUsername();
                break;

                case 'checkEmail':
                    // Manejo de la verificación de correo electrónico
                    $this->handleEmail();
                break;

                case 'SendEmail':
                    // Manejo del envío de correo electrónico
                    $this->handleSendEmail();
                break;

                default:
                    $this->response(['error' => 'Recurso no encontrado'], 404);
                break;
            }
        } else {
            $this->response(['error' => 'Recurso no especificado'], 400);
        }
    }

    private function handleLogin() {
        $username = isset($_POST['username']) ? trim($_POST['username']) : '';
        $password = isset($_POST['password']) ? trim($_POST['password']) : '';
        $model = new LoginRepository(); // Inicializa el LoginRepository aquí

        if (!empty($username) && !empty($password)) {
            //var_dump($username, $password); // Para depuración
            $userExists = $model->GetUsernameUser($username);
            if ($userExists > 0) {
                $passwordMatch = $model->GetPasswordUser($username, $password);
                if ($passwordMatch > 0) {
                    $userData = $model->GetUserData($username, $password);
                    if ($userData['status'] != 3 && $userData['status'] != 4) {
                        $_SESSION["cedula"]     = $userData['cedula'];
                        $_SESSION['id_user']    = (int) $userData['id_user'];
                        $_SESSION["usuario"]    = $userData['usuario'];
                        $_SESSION["nombres"]    = $userData['nombres'];
                        $_SESSION["apellidos"]  = $userData['apellidos'];
                        $_SESSION["correo"]     = $userData['correo'];
                        $_SESSION['d_rol']      = (int) $userData['codtipousuario'];
                        $_SESSION['name_rol']   = $userData['name_rol'];
                        $_SESSION['status']     = (int) $userData['status'];

                        $session_lifetime = 1200; // Ejemplo: 20 minutos en segundos
                        $_SESSION['session_lifetime'] = $session_lifetime;

                        // Regenerar el ID de sesión antes de usar session_id()
                        session_regenerate_id(true);
                        // Configurar la zona horaria a Venezuela (Caracas)
                        date_default_timezone_set('America/Caracas');
                        // Generar id_session
                        $session_id = session_id();
                        $_SESSION["session_id"] = $session_id;
                        // Obtener datos adicionales
                        $start_date = date('Y-m-d H:i:s');
                        $user_agent = $_SERVER['HTTP_USER_AGENT'];
                        $ip_address = $_SERVER['REMOTE_ADDR'];
                        $active = 1;
                        $expiry_time_unix = time() + $session_lifetime;
                        $expiry_time = date('Y-m-d H:i:s', $expiry_time_unix); // Convertir a formato DATETIME

                        // Asegúrate de que GetSession en tu modelo LoginRepository tome el id_user correctamente
                        $result9 = $model->GetSession($session_id);
                        
                        if($result9 > 0){
                            $this->response([
                                'success' => false,
                                'message' => 'Ya existe una sesión activa para este usuario.',
                                'redirect' => 'login'
                            ], 409); // Código de estado 409 Conflict
                        } else {
                            $insertResult = $model->InsertSession($session_id, $start_date,  $user_agent, $ip_address, $active, $expiry_time);
                            if ($insertResult) {
                                $redirectURL = '';
                                switch ($userData['codtipousuario']) {
                                    case 1: $redirectURL = 'dashboard'; break;
                                    case 2: $redirectURL = 'dashboard2'; break;
                                    case 3: $redirectURL = 'dashboard3'; break;
                                    case 4: $redirectURL = 'dashboard4'; break;
                                    case 5: $redirectURL = 'dashboard5'; break;
                                }
                                $model->UpdateTryPassTo0($username);
                                $this->response([
                                    'success' => true,
                                    'message' => 'Inicio de sesión exitoso',
                                    'redirect' => $redirectURL,
                                    'session_lifetime' => $_SESSION['session_lifetime'],
                                    'session_id' => $_SESSION["session_id"]
                                ], 200);
                            } else {
                                $this->response(['error' => 'Error al guardar la información de la sesión'], 500);
                            }
                        }
                    } else {
                        $this->response(['success' => false, 'message' => 'Usuario inactivo o bloqueado'], 401);
                    }
                } else {
                    $model->UpdateTryPass($username);
                    $attempts = $model->GetTryPass($username);
                    if ($attempts <= 3) {
                        $this->response(['success' => false, 'message' => 'Contraseña incorrecta. Intentos restantes: ' . (3 - $attempts)], 401);
                    } else {
                        $model->UpdateStatusTo4($username);
                        $this->response(['success' => false, 'message' => 'Usuario bloqueado por intentos fallidos'], 403);
                    }
                }
            } else {
                $this->response(['success' => false, 'message' => 'Usuario no existe'], 401);
            }
        } else {
            $this->response(['success' => false, 'message' => 'Usuario o contraseña están vacíos'], 400);
        }
    }

    private function handlePassword(){
        $username = isset($_POST['username']) ? $_POST['username'] : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $model = new LoginRepository(); // Inicializa el LoginRepository aquí

        if ($password != '') {
            $result = $model->GetPasswordUser( $username,$password);
            if ($result > 0) {
                $this->response(['success' => true,'message' => 'La clave coincide con el usuario', 'color'   => 'green']);
            } else {
                $this->response(['success' => false,'message' => 'No coincide con el usuario','color'=> 'red']);
            }
        } else {
            $this->response(['success' => false,'message' => 'Usuario o contraseña están vacíos','color'=> 'red']);
        }

    }

    public function handleUsername(){
        $username = isset($_POST['username']) ? $_POST['username'] : '';
        $model = new LoginRepository(); // Inicializa el LoginRepository aquí

        if($username != '') {
            $result = $model->GetUsernameUser($username);
            if ($result > 0) {
                $this->response(['success' => true, 'message' => 'Usuario Verificado', 'color'   => 'green']);
            }else{
                $this->response(['success' => false, 'message' => 'Usuario No Existe', 'color'=> 'red']);
            }
        }else{
            $this->response(['success' => false, 'message' => 'Campo vacíos', 'color'=> 'red']);
        }
    }

    public function handleEmail(){
        $email = isset($_POST['email']) ? $_POST['email'] : '';
        $model = new LoginRepository(); // Inicializa el LoginRepository aquí

        if($email != '') {
            $result = $model->GetEmailUser($email);
            if ($result > 0) {
                $this->response([ 'success' => true, 'message' => 'Correo Verificado', 'color'   => 'green']);
            }else{
                $this->response(['success' => false, 'message' => 'Correo No Existe', 'color'=> 'red']);
            }
        }else{
            $this->response(['success' => false, 'message' => 'Campo vacíos', 'color'=> 'red']);
        }
    }

    public function handleSendEmail(){
        $email = isset($_POST['email']) ? $_POST['email'] : '';
        $model = new LoginRepository(); // Inicializa el LoginRepository aquí

        if ($email != '') {
            $result  = $model->GetEmailUserData($email);
            $nombres = $result;
            if ($result > 0) {
                // Generar código
                $longitud = 6;
                $caracteres = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $codigo = '';
                for ($i = 0; $i < $longitud; $i++) {
                    $codigo .= $caracteres[rand(0, strlen($caracteres) - 1)];
                }
                // Configuración de PHPMailer
                $mail = new PHPMailer(true); /*SMTP::DEBUG_OFF;*/

                try { 
                    // Configuración del servidor SMTP
                    $mail->SMTPDebug  = SMTP::DEBUG_OFF; // Habilita la depuración (opcional)
                    $mail->isSMTP();
                    $mail->Host       = SMTP_HOST;
                    $mail->SMTPAuth   = SMTP_AUTH;
                    $mail->Username   = SMTP_USERNAME;
                    $mail->Password   = SMTP_PASSWORD;
                    $mail->SMTPSecure = SMTP_SECURE;
                    $mail->Port       = SMTP_PORT;

                    // Remitente y destinatario
                    $mail->setFrom(SMTP_USERNAME, 'SOPORTE POST-VENTA INTELIGENSA');
                    $mail->addAddress($email); // Asume que $result['nombre'] contiene el nombre del usuario
                    // Contenido del correo
                    $mail->isHTML(true); // O true si quieres enviar HTML
                    $mail->CharSet = 'UTF-8';

                    $mail->Subject = 'Restablece tu contraseña';
                    // Adjuntar la imagen
                    $mail->addEmbeddedImage(FIRMA_CORREO, 'imagen_adjunta');

                    $mail->Body    = '
                    <h2 style = "color: #3f85ff; font-size: 23px; text-align: center; margin-bottom: 20px;">Restablecer Contraseña</h2>
                    <strong><p style = " margin-bottom: 15px;">Hola, '.$nombres.'</p></strong>
                    <strong><p>Recibimos una solicitud para restablecer tu contraseña. Si no realizaste esta solicitud, puedes ignorar este correo.</p></strong>
                    <strong><p>Para restablecer tu contraseña, utiliza el siguiente código: <span style = "background-color: #3f85ff; padding: 10px; border-radius: 5px; font-family: monospace; font-size: 3.2em; text-align: center; margin: 22px auto; width: 200px; height: 50px; display: block; width: fit-content; border: 1px solid #000000;" class = "code">'.$codigo.'</span></p><strong>
                    <p style = "text-align: center; color: red; font-size: 0.9em;">Este código será su contraseña. Cambie nuevamente al iniciar Sesión.</p>
                    <p style = "text-align: center; color: #777; font-size: 0.9em;">ATT: InteliSoft</p>
                    <img src="cid:imagen_adjunta" alt="Logo de la empresa" style="display: block; margin: 0 auto; width: 150px;">';
                    $mail->send();
                    $this->response(['success' => true, 'message' => 'contraseña enviada. Revisa tu correo.', 'color'=> 'green']);
                    $model->ChangePassForCode($codigo, $email);
                    $model->UpdateStatusTo1($email);
                    $model->UpdateTimePass($email);
                    
                } catch (Exception $e) {
                    $this->response(['success' => false, 'message' =>  'Error al enviar el correo: ' . $mail->ErrorInfo, 'color'=> 'red']);
                }
            } else {
                $this->response(['success' => false, 'message' =>   'Correo no encontrado.', 'color'=> 'red']);
            }
        } else {
            $this->response(['success' => false, 'message' =>   'Campo vacío.', 'color'=> 'red']);
        }
    }


    private function response($data, $status = 200) {
        header('Content-Type: application/json');
        http_response_code($status);
        echo json_encode($data);
        exit();
    }

    function handleUsers($method, $urlSegments) {
        // var_dump($model); // Para depuración     
        switch ($method) {
            case 'GET':
                if (isset($urlSegments[1]) && is_numeric($urlSegments[1])) {
                    $this->GetUserById($urlSegments[1]); // Obtener usuario por ID
                } else {
                    $this->getAllUsers(); // Obtener todos los usuarios
                }
                break;
            default:
                $this->response(['error' => 'Método no permitido para /api/users'], 405);
                break;
        }
    }

    function getAllUsers() {
        $model = new UserRepository();
        $users = $model->getAllUsers(); // Obtiene el array de usuarios directamente
    
        if ($users !== null) {
            echo json_encode($users);
        } else {
            $this->response(['error' => 'Error al obtener los usuarios'], 500);
        }
    }

    function GetUserById($id) {
        $model = new UserRepository();
        $user = $model->GetUserById($id);
        if ($user !== null) {
            echo json_encode($user);
        } else {
            $this->response(['error' => 'Usuario no encontrado'], 404);
        }
    }
}
?>