<?php
require_once __DIR__ . "/../../libs/Model.php";
require_once __DIR__ . "/../../libs/session.php";
class loginModel extends Model{
    
    public $db;

    public function __construct(){
        parent::__construct();
        $this->db = DatabaseCon::getInstance(bd_hostname, mvc_port, bd_usuario, bd_clave, database);
    }
    
    /*public function GetUserData($username, $password){
        try{
            $sql = "SELECT * FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
                 'SELECT usuario, clave, coddocumento, nombres, apellidos, correo, codtipousuario,
					        activo, cargo FROM tblusuario') 
                            AS informacion_clientes (usuario varchar(100), clave 
                            varchar(100), coddocumento VARCHAR(20), nombres varchar(50), 
                            apellidos varchar(50), correo VARCHAR (50), codtipousuario character(50), activo character, cargo varchar(100)) 
                    WHERE usuario = '".$username."' AND clave = '".$password."';";
            $result = Model::getResult($sql, $this->db);
           // var_dump($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        } 
    }*/

    public function GetUserData($username, $password){
        try{
            $sql = "SELECT usr.id_user, usr.username AS usuario, usr.password AS clave, usr.national_id AS cedula, usr.name AS nombres, usr.surname AS apellidos,
            usr.email AS correo, usr.id_rolusr AS codtipousuario, rol.name_rol AS name_rol, usr.id_statususr AS status FROM users usr
            INNER JOIN roles rol ON usr.id_rolusr = rol.id_rolusr
            WHERE username = '".$username."' AND password = '".$password."';";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        } 
    }

    /*public function GetUsernameUser($username){
        try{
            $sql ="SELECT usuario FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
                 'SELECT usuario FROM tblusuario') 
                            AS usuario (usuario VARCHAR (50)) 
                    WHERE usuario = '".$username."';";
            $result = Model::getResult($sql, $this->db);
            return $result;
          // Depuración: imprime la consulta SQL y el resultado
           } catch (Throwable $e) {
            // Handle exception
        }
    }*/

    public function GetUsernameUser($username){
        try{
            $sql = "SELECT username FROM users WHERE username = '".$username."';";
            $result = Model::getResult($sql, $this->db);
            return $result;
          // Depuración: imprime la consulta SQL y el resultado
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    /*public function GetPasswordUser($username, $password){  
        try {
            $sql = "SELECT usuario, clave FROM dblink('host=127.0.0.1 port=5432 dbname=Intelipunto user=postgres password=Airan1234',
                 'SELECT usuario, clave FROM tblusuario') 
                            AS usuario_clave (usuario varchar(50), clave VARCHAR (200)) 
                    WHERE usuario = '".$username."' AND clave = '".$password."';";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }*/

    public function GetPasswordUser($username, $password){  
        try {
            $sql = "  SELECT username, password FROM users WHERE username = '".$username."' AND password = '".$password."';";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function GetEmailUser($email){
        try{
            $sql = "SELECT u.email, u.national_id as coddocumento, u.id_user, CONCAT(u.name, ' ', u.surname) AS nombre_completo 
            FROM users u WHERE u.email = '".$email."';";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    /*public function GetStatusUser($username){
        try{
            $sql = "SELECT id_statususr FROM users WHERE username = '".$username."';";
            $result = Model::getResult($sql, $this->db);
            //var_dump($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }*/

    public function ChangePassForCode($codigo, $email){
        try{
            $sql = "UPDATE users SET password = '".$codigo."' WHERE email = '".$email."';";
            //var_dump($sql);
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function UpdateTryPass($username){
        try{
            $sql = "UPDATE users SET trying_failedpassw = trying_failedpassw +  1 WHERE username = '".$username."';";
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function GetTryPass($username){
        try{
            $sql = "SELECT trying_failedpassw FROM users WHERE username = '".$username."';";
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
        // Handle exception
        }
    }

    public function UpdateTimePass($email){
        try{
            $sql = "UPDATE users SET trying_failedpassw = 0 WHERE email = '".$email."';";
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function UpdateStatusTo4($username){
        try{
            $sql = "UPDATE users SET id_statususr = 4 WHERE username = '".$username."';";
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function UpdateStatusTo1($email){
        try{
            $sql = "UPDATE users SET id_statususr = 1 WHERE email = '".$email."';";
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function UpdateStatusTo0($username){
        try{
            $sql = "UPDATE users SET trying_failedpassw = 0 WHERE username = '".$username."';";
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function InsertSession($session_id, $start_date, $id_user, $user_agent, $ip_address, $active, $expiry_time){
        try{
            $sql = "INSERT INTO sessions_users (id_session, id_user, start_date, user_agent, ip_address, active, expiry_time) 
            VALUES ('".$session_id."', ".$id_user.",  '".$start_date."', '".$user_agent."', '".$ip_address."', ".$active.", '".$expiry_time."');";
            //var_dump($sql);
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function GetSession($id_user, $id_session){
        try{
            $sql = "SELECT * FROM sessions_users  WHERE id_user = " . $id_user . " AND active = 1  AND (id_session != '" . $id_session . "')";
            //var_dump($sql);
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function UpdateSession($id_user,  $session_id){
        try{
            $sql = "UPDATE sessions_users SET end_date = NOW(), active = 0 WHERE id_user = ".$id_user." AND id_session = '". $session_id."';";
            //var_dump($sql);
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Handle exception
        }
    }

    public function GetExpiredSessions($usuario_id, $ahora) {
        try {
            $sql = "SELECT id_session FROM sessions_users WHERE id_user = ".$usuario_id." AND active = 1 AND expiry_time <= '".$ahora."';";
            //var_dump($sql);
            $result = Model::getResult($sql, $this->db);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }

    public function UpdateSessionExpired($id_session) {
        try {
            $sql = "UPDATE sessions_users SET active = 0, end_date = NOW() WHERE id_session = '".$id_session."';";
            //var_dump($sql);
            $result = $this->db->pgquery($sql);
            return $result;
        } catch (Throwable $e) {
            // Manejar excepciones
        }
    }
}
//Fin Modelo
?>